import axios from 'axios';
import IArtist from '../interfaces/IArtist';

const ArtistService = (
  () => {

    const artistEndpoints = {
      artists: "https://localhost:7003/Artist",
      artistByName: "https://localhost:7003/Artist/GetArtistByName?artistName="
    }

    const getAllArtists = async () => {
      try{
        const result = await axios.get(artistEndpoints.artists);
        return result.data;
      }catch (error){
        console.log('Error:', error);
      }
    }

    const getArtistById = async (id: number) => {
      const result = await axios.get(`${artistEndpoints.artists}/${id}`);
      return result.data;
    }

    const getArtistByName = async (name: string) => {
      const result = await axios.get(`${artistEndpoints.artistByName}${name}`);
      return result.data;
    }

    const postArtist = async (a: IArtist) => {
        const result = await axios.post(artistEndpoints.artists, a);
        console.log(result);
    }

    const putArtist = async (a: IArtist) => {
      const result = await axios.put(artistEndpoints.artists, a);
      return result.data;
    }

    const deleteArtist = async (id: number) => {
      const result = await axios.delete(`${artistEndpoints.artists}/${id}`)
      return result;
    }

    return {
      getAllArtists,
      getArtistByName,
      getArtistById,
      postArtist,
      putArtist,
      deleteArtist,
    }

  }
)();

export default ArtistService;
import ArtistList from "../../components/artists/ArtistList";
import UpdateArtist from "../../components/artists/UpdateArtist";

const UpdateArtistPage = () => {
  return (
      <div className="container mt-4">
          <UpdateArtist/>
          <ArtistList/>
      </div>
  )
}

export default UpdateArtistPage;
import ArtistList from "../../components/artists/ArtistList";
import SearchForArtist from "../../components/artists/SearchForArtist";
import ArtistSearch from "../../components/artists/SearchForArtist";

const ShowArtistByNamePage = () => {
  return (
      <div className="container mt-4">
        <SearchForArtist/>
      </div>
  )
}

export default ShowArtistByNamePage;
import { useState, useRef, useEffect, useContext } from "react";
import IArtist from "../../interfaces/IArtist";
import ArtistItem from "./ArtistItem";
import ArtistService from "../../services/ArtistService";

const SearchForArtist = () => {

  const idNumberElement = useRef<HTMLInputElement>(null)
  const [artist, setartist] = useState<IArtist | null>(null)
  const [searchValue, setsearchValue] = useState<string>("")

  const getArtistById = async () => {
    if(idNumberElement.current){
      const artistNumber = idNumberElement.current.value
      const chosenArtist: IArtist = await ArtistService.getArtistById(parseInt(artistNumber));
      setartist(chosenArtist);
    }
  }

  useEffect(() => {
    setsearchValue(searchValue);
  }, [searchValue]);

  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const searchName = event.target.value;
    setsearchValue(searchName);
  }

  const getArtistByName = async () => {
    const chosenArtist: IArtist[] = await ArtistService.getArtistByName(searchValue);
    if(chosenArtist.length > 0){
      const artistObject = chosenArtist[0];
      console.log("Chosen artist: " + artistObject.artistName);
      setartist(artistObject);
    }
  }

  return (
    <section className="margin">
      
      <h2>Search for Artist</h2>

      <div className="form-group">
        <label className="form-label">Type the ID of the artist you want to search for</label>
        <input className="form-control" ref={idNumberElement} type="number" placeholder="Artist ID here" />
      </div>
      <button className="btn btn-primary mt-3" onClick={getArtistById}>Search</button>

      <div className="form-group">
        <label className="form-label">Search for an artist by name</label>
        <input className="form-control" value={searchValue} onChange={(e) => handleNameChange(e)} placeholder="Artist name here" />
      </div>
      <button className="btn btn-primary mt-3" onClick={() => getArtistByName()}>Search by name</button>

      <div className="form-group mt-3">
        {artist?
          <ArtistItem 
            id={artist.id}
            artistName={artist.artistName}
            genre={artist.genre}
            image={artist.image}
          />
          : "" 
        }
      </div>

    </section>
  )
}

export default SearchForArtist;
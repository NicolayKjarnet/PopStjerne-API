import {useContext, useEffect} from "react";
import {ArtistContext} from "../../contexts/ArtistContext";
import IArtistContext from "../../interfaces/IArtistContext";
import ArtistItem from "./ArtistItem";

const ArtistList = () => {

    const {artistArray} = useContext(ArtistContext) as IArtistContext;

    useEffect(() => {
        getArtistList();
    }, [])

    const getArtistList = () => {
        if(artistArray){
            return artistArray.map((artist, i) => (
                <ArtistItem
                    key={`artist-${i}`}
                    id={artist.id}
                    artistName={artist.artistName}
                    genre={artist.genre}
                    image={artist.image}
                />
            ));
        } else {
            return <p>No artists found.</p>;
        }
    };

    return (
        <section>
        <h2>Artists</h2>
        <p>Number of artists: {artistArray.length}</p>
            <div className="artist-container row">
                {getArtistList()}
            </div>
        </section>
    )
}

export default ArtistList;
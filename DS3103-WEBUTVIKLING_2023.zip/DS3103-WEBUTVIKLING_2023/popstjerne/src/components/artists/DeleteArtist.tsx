import { useState, useContext, ChangeEvent } from "react";
import { ArtistContext } from "../../contexts/ArtistContext";
import IArtistContext from "../../interfaces/IArtistContext";
import ArtistService from "../../services/ArtistService";

const DeleteArtist = () => {

    const [id, setId] = useState<number>(0);
    const {deleteArtist} = useContext(ArtistContext) as IArtistContext;

    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
        setId(parseInt(e.currentTarget.value));
    }

    const deleteArtistById = async () => {

        const artist = await deleteArtist(id);

        if (artist !== null && artist !== undefined) {
            alert(`ID: ${artist.id} (${artist.artistName}) was successfully deleted.`);
        } else {
            alert(`Artist with ID ${id} was not found.`);
        }
    }

    return (
        <section className="margin">
        <h2>Delete Artist</h2>
        <div className="row mb-3">
            <div className="col-12 col-lg-4 mb-3 mb-lg-0">
                <label htmlFor="artistId" className="form-label">Type the ID of the artist you want to delete</label>
                <input id="artistId" className="form-control" type="number" value={id} onChange={handleChange} />
            </div>
            <div className="col-12 col-lg-3 d-flex align-items-end">
                <button className="btn btn-danger" onClick={deleteArtistById}>Delete</button>
            </div>
        </div>
        </section>
    )
}

export default DeleteArtist;
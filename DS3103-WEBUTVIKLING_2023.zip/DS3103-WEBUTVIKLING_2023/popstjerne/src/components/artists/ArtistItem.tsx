import {FC} from "react"
import IArtist from "../../interfaces/IArtist"

const ArtistItem: FC<IArtist> = ({id, artistName, genre, image}) => {
    return (
        <div className="col-md-6 mt-3">
            <article className="card bg-dark">
                <img className="card-img-top" src={`https://localhost:7003/images/artists/${image}`} alt={`${artistName}`} />
                    <div className="card-body artist-info">
                        <h3 className="card-title">{artistName}</h3>
                        <p className="card-text text-light">
                            Genre: {genre}
                        <br/>
                            ID: {id}
                        </p>
                    </div>
            </article>
        </div>
    )
}

export default ArtistItem;
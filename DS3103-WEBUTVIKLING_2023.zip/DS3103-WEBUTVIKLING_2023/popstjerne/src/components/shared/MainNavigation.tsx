import {Link} from 'react-router-dom';
import '../../App.css';

const MainNavigation = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-dark">
            <div className="container justify-content-center">
                <ul className="navbar-nav">
                    <li className="nav-item"><Link to="/" className="nav-link">Home</Link></li>
                    <li className="nav-item"><Link to='http://127.0.0.1:5500/wwwroot/index.html' className="nav-link">Docs</Link></li>
                    <li className="nav-item"><Link to="about" className="nav-link">About</Link></li>
                    <li className="nav-item"><Link to="add-new-artist" className="nav-link">Add New Artist</Link></li>
                    <li className="nav-item"><Link to="search-artist" className="nav-link">Search Artists</Link></li>
                    <li className="nav-item"><Link to="update-artist" className="nav-link">Update Artists</Link></li>
                    <li className="nav-item"><Link to="delete-artist" className="nav-link">Delete Artists</Link></li>
                </ul>
            </div>
        </nav>
    )
}

export default MainNavigation;
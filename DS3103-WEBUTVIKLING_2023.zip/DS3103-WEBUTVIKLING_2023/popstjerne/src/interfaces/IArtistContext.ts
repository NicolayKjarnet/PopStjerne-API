import IArtist from "./IArtist";

// Interface for array and methods used in the ArtistContext class
interface IArtistContext {
    artistArray: IArtist[];
    getAllArtists: (artist: IArtist) => void;
    getArtistById: (id: number) => void;
    getArtistByName: (name: string) => void;
    addArtist: (artist: IArtist) => void;
    updateArtist: (artist: IArtist) => void;
    deleteArtist: (id: number) => Promise<IArtist | undefined>;
}

export default IArtistContext;
interface IArtist {
    id?: number, // ? because db auto-increments id, but we still need id in interface for valid artist objects
    artistName: string,
    genre: string,
    image: string
}

export default IArtist;
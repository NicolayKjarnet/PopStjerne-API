import { useState, createContext, FC, ReactNode, useEffect } from "react";
import IArtist from "../interfaces/IArtist";
import IArtistContext from "../interfaces/IArtistContext";
import ArtistService from "../services/ArtistService";

export const ArtistContext = createContext<IArtistContext | null>(null)

interface Props{
    children: ReactNode,
}

export const ArtistProvider : FC<Props> = ({children}) => {

    const [artistArray, setArtist] = useState<IArtist[]>([]);

    useEffect(() => {
        getAllArtists();
    }, []);

    const getAllArtists = async () : Promise<void> => {
        try {
            const allArtists = await ArtistService.getAllArtists();
            setArtist(allArtists);

            return allArtists;

        } catch (error){
            console.error(error);
            throw new Error("Failed to get all artists.");
        }
    }

    const getArtistById = async(id: number) => {
        const artist = await ArtistService.getArtistById(id);
        console.log(artist);
    }

    const getArtistByName = async(name: string) => {
        const getArtistByName = await ArtistService.getArtistByName(name);
        console.log(getArtistByName);
    }

    const addArtist = async (artist: IArtist) => {
        setArtist([artist, ...artistArray]);
        await ArtistService.postArtist(artist);
    }

    const updateArtist = async (artist: IArtist) => {
        setArtist([artist, ...artistArray]);
        await ArtistService.putArtist(artist);
    }

    const deleteArtist = async (id: number) : Promise<IArtist | undefined> => {
        try {
            await ArtistService.deleteArtist(id);
            const newArtistArray = artistArray.filter((artist) => artist.id !== id);
            setArtist(newArtistArray);
            const deletedArtist = artistArray.find((artist) => artist.id === id);
        
            return deletedArtist;
        } catch {
            return undefined;
        }
    };

    // Giving all children of the component access to the array of artists and methods using the Provider
    return(
        <ArtistContext.Provider value={{artistArray, getAllArtists, getArtistById, getArtistByName, addArtist, updateArtist, deleteArtist}}>
            {children}
        </ArtistContext.Provider>
    )
}
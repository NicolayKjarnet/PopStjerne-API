import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainPageHeader from './components/shared/MainPageHeader';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AboutPage, AddNewArtistPage, DeleteArtistPage, HomePage, ShowArtistByNamePage, UpdateArtistPage } from './pages/Index';


function App() {
  return (
    <div>

    <BrowserRouter>

    <MainPageHeader/>

    <main className='container'>
      <Routes>
        <Route path='/' element={<HomePage/>}></Route>
        <Route path='about' element={<AboutPage/>}></Route>
        <Route path='add-new-artist' element={<AddNewArtistPage/>}></Route>
        <Route path='search-artist' element={<ShowArtistByNamePage/>}></Route>
        <Route path='update-artist' element={<UpdateArtistPage/>}></Route>
        <Route path='delete-artist' element={<DeleteArtistPage/>}></Route>
      </Routes>
    </main>

    </BrowserRouter>

    </div>
  );
}

export default App;

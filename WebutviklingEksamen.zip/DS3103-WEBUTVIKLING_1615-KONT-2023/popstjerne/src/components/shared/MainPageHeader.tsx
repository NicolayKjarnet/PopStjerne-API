import { Link } from "react-router-dom";
import MainNavigation from "./MainNavigation";

const MainPageHeader = () => {
    return (
        <header className="header main-page-header py-5">
            <div className="container text-center">
                <Link to="/" className="header-title text-decoration-none h1 d-block mb-0">PopStjerne API</Link>
                <MainNavigation></MainNavigation>
            </div>
        </header>
    )
}

export default MainPageHeader;
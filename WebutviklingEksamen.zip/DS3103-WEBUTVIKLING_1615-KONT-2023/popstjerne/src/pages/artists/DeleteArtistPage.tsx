import ArtistList from "../../components/artists/ArtistList";
import DeleteArtist from "../../components/artists/DeleteArtist";

const DeleteArtistPage = () => {
  return (
      <div className="container mt-4">
          <DeleteArtist/>
          <ArtistList/>
      </div>
  )
}

export default DeleteArtistPage;
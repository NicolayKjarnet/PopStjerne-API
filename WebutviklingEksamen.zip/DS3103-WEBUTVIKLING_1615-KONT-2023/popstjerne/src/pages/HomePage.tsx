import ArtistList from "../components/artists/ArtistList";

const HomePage = () => {
    return (
        <div className="container mt-4">
            <ArtistList/>
        </div>
    )
  }
  
  export default HomePage;